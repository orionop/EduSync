import { supabase } from '../lib/supabase';
import type { Database } from '../types/supabase';

type Tables = Database['public']['Tables'];
type ExamApplication = Tables['exam_applications']['Row'];
type ExamApplicationInsert = Tables['exam_applications']['Insert'];
type ApplicationSubject = Tables['application_subjects']['Row'];

interface Subject {
  code: string;
  name: string;
  category: 'core' | 'elective';
  semester: number;
}

interface Student {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
}

interface ExamApplicationRequest {
  studentId: string;
  examScheduleId: string;
  semester: number;
  subjectIds: string[];
}

interface ExamApplicationResponse {
  applicationId: string;
  status: 'success' | 'error';
  message: string;
}

// Mock data for subjects (replace with actual database data)
const subjects: Subject[] = [
  { code: 'CS401', name: 'Data Structures', category: 'core', semester: 4 },
  { code: 'CS402', name: 'Computer Networks', category: 'core', semester: 4 },
  { code: 'CS403', name: 'Database Management', category: 'core', semester: 4 },
  { code: 'CS404', name: 'Machine Learning', category: 'elective', semester: 4 },
  { code: 'CS405', name: 'Cloud Computing', category: 'elective', semester: 4 },
  // Add more subjects as needed
];

export const generateExamApplication = async (
  request: ExamApplicationRequest
): Promise<ExamApplicationResponse> => {
  try {
    // 1. Verify student exists and get details
    const { data: student, error: studentError } = await supabase
      .from('students')
      .select(`
        id,
        users!inner (
          first_name,
          last_name,
          email
        )
      `)
      .eq('id', request.studentId)
      .single();

    if (studentError || !student) {
      return {
        applicationId: '',
        status: 'error',
        message: 'Student not found'
      };
    }

    // 2. Verify exam schedule exists
    const { data: examSchedule, error: scheduleError } = await supabase
      .from('exam_schedules')
      .select('*')
      .eq('id', request.examScheduleId)
      .single();

    if (scheduleError || !examSchedule) {
      return {
        applicationId: '',
        status: 'error',
        message: 'Exam schedule not found'
      };
    }

    // 3. Verify subjects exist and belong to student's program
    const { data: subjects, error: subjectsError } = await supabase
      .from('subjects')
      .select('*')
      .in('id', request.subjectIds);

    if (subjectsError || !subjects || subjects.length !== request.subjectIds.length) {
      return {
        applicationId: '',
        status: 'error',
        message: 'Invalid subjects selected'
      };
    }

    // 4. Generate application ID (e.g., EA2024001)
    const { data: lastApp } = await supabase
      .from('exam_applications')
      .select('id')
      .order('created_at', { ascending: false })
      .limit(1);

    const newAppNumber = lastApp?.length ? 
      parseInt(lastApp[0].id.slice(6)) + 1 : 
      1;
    const applicationId = `EA${new Date().getFullYear()}${newAppNumber.toString().padStart(3, '0')}`;

    // 5. Create exam application
    const applicationData: ExamApplicationInsert = {
      id: applicationId,
      student_id: request.studentId,
      exam_schedule_id: request.examScheduleId,
      semester: request.semester,
      status: 'pending',
      submitted_at: new Date().toISOString(),
      payment_status: 'pending',
      payment_amount: 1000.00 // You might want to make this configurable
    };

    const { data: application, error: applicationError } = await supabase
      .from('exam_applications')
      .insert(applicationData)
      .select()
      .single();

    if (applicationError || !application) {
      return {
        applicationId: '',
        status: 'error',
        message: 'Failed to create application'
      };
    }

    // 6. Create application subjects
    const applicationSubjects = request.subjectIds.map(subjectId => ({
      id: `AS${Date.now()}${Math.random().toString(36).slice(2, 5)}`,
      application_id: applicationId,
      subject_id: subjectId
    }));

    const { error: subjectsInsertError } = await supabase
      .from('application_subjects')
      .insert(applicationSubjects);

    if (subjectsInsertError) {
      // Rollback application creation
      await supabase
        .from('exam_applications')
        .delete()
        .eq('id', applicationId);

      return {
        applicationId: '',
        status: 'error',
        message: 'Failed to create application subjects'
      };
    }

    return {
      applicationId: application.id,
      status: 'success',
      message: 'Exam application submitted successfully'
    };

  } catch (error) {
    console.error('Error in generateExamApplication:', error);
    return {
      applicationId: '',
      status: 'error',
      message: 'Internal server error'
    };
  }
};

export const getExamApplication = async (applicationId: string) => {
  try {
    const { data: application, error } = await supabase
      .from('exam_applications')
      .select(`
        *,
        student:students!inner (
          id,
          roll_number,
          users!inner (
            first_name,
            last_name,
            email
          )
        ),
        exam_schedule:exam_schedules!inner (*),
        application_subjects!inner (
          subjects!inner (*)
        )
      `)
      .eq('id', applicationId)
      .single();

    if (error) throw error;
    return application;

  } catch (error) {
    console.error('Error in getExamApplication:', error);
    return null;
  }
};

export const processExamApplication = async (
  applicationId: string,
  status: 'approved' | 'rejected',
  processedBy: string
) => {
  try {
    const { data, error } = await supabase
      .from('exam_applications')
      .update({
        status,
        processed_at: new Date().toISOString(),
        processed_by: processedBy
      })
      .eq('id', applicationId)
      .select()
      .single();

    if (error) throw error;

    // If approved, generate hall ticket
    if (status === 'approved') {
      // You'll implement this later in hallTicketService
      // await generateHallTicket({ applicationId });
    }

    return true;

  } catch (error) {
    console.error('Error in processExamApplication:', error);
    return false;
  }
};

// Helper function to generate PDF (mock for now)
const generateApplicationPDF = async (application: ExamApplication): Promise<string> => {
  // Implement PDF generation logic here
  // This could use a library like PDFKit or jsPDF
  return `https://example.com/pdfs/${application.id}.pdf`;
};

// Example usage:
/*
// Student submitting application
const request: ExamApplicationRequest = {
  studentId: "STU001",
  semester: 4,
  electiveSubjectCodes: ["CS404", "CS405"] // Selected elective subjects
};

const response = await generateExamApplication(request);
console.log(response);
// Output: { applicationId: "APP1234567890", status: "success", message: "Exam application submitted successfully" }

// Admin processing application
const success = await processExamApplication("APP1234567890", "approved");
console.log(success);
// Output: true

// Getting application details
const application = await getExamApplication("APP1234567890");
console.log(application);
// Output: { id: "APP1234567890", studentId: "STU001", ... }
*/ 