interface MarksEvaluation {
  studentId: string;
  subjectCode: string;
  internalAssessment: number;  // out of 20
  midSemExam: number;         // out of 20
  termWork: number;           // out of 20
  practicals: number;         // out of 20
}

interface EndSemEvaluation {
  studentId: string;
  subjectCode: string;
  marks: number;              // out of 60
}

interface SubjectResult {
  subjectCode: string;
  subjectName: string;
  credits: number;
  internalAssessment: number;
  midSemExam: number;
  termWork: number;
  practicals: number;
  endSemMarks: number;
  totalMarks: number;
  grade: string;
  gradePoint: number;
}

interface StudentResult {
  studentId: string;
  studentName: string;
  rollNumber: string;
  semester: number;
  results: SubjectResult[];
  sgpa: number;
  status: 'pass' | 'fail';
}

interface ResultGenerationRequest {
  semester: number;
  studentIds: string[];
}

interface ResultGenerationResponse {
  status: 'success' | 'error';
  message: string;
  results?: StudentResult[];
}

// Grade calculation based on total marks
const calculateGrade = (totalMarks: number): { grade: string; gradePoint: number } => {
  if (totalMarks >= 80) return { grade: 'O', gradePoint: 10 };
  if (totalMarks >= 75) return { grade: 'A+', gradePoint: 9 };
  if (totalMarks >= 70) return { grade: 'A', gradePoint: 8 };
  if (totalMarks >= 60) return { grade: 'B+', gradePoint: 7 };
  if (totalMarks >= 50) return { grade: 'B', gradePoint: 6 };
  if (totalMarks >= 45) return { grade: 'C', gradePoint: 5 };
  if (totalMarks >= 40) return { grade: 'P', gradePoint: 4 };
  return { grade: 'F', gradePoint: 0 };
};

// Calculate SGPA
const calculateSGPA = (results: SubjectResult[]): number => {
  let totalCreditPoints = 0;
  let totalCredits = 0;

  results.forEach(result => {
    totalCreditPoints += result.credits * result.gradePoint;
    totalCredits += result.credits;
  });

  return totalCredits > 0 ? Number((totalCreditPoints / totalCredits).toFixed(2)) : 0;
};

// Mock subject data (replace with actual database data)
const subjects = [
  { code: 'CS401', name: 'Data Structures', credits: 4 },
  { code: 'CS402', name: 'Computer Networks', credits: 4 },
  { code: 'CS403', name: 'Database Management', credits: 4 },
  { code: 'CS404', name: 'Machine Learning', credits: 3 },
  // Add more subjects as needed
];

export const generateResults = async (
  request: ResultGenerationRequest
): Promise<ResultGenerationResponse> => {
  try {
    const results: StudentResult[] = [];

    // Process each student
    for (const studentId of request.studentIds) {
      // 1. Fetch student details (mock for now)
      const student = {
        id: studentId,
        name: 'John Doe',
        rollNumber: '2023001'
      };

      // 2. Fetch marks evaluation data (mock for now)
      const marksEvaluation: MarksEvaluation[] = [
        {
          studentId,
          subjectCode: 'CS401',
          internalAssessment: 18,
          midSemExam: 16,
          termWork: 18,
          practicals: 19
        },
        // Add more subjects
      ];

      // 3. Fetch end sem evaluation data (mock for now)
      const endSemEvaluation: EndSemEvaluation[] = [
        {
          studentId,
          subjectCode: 'CS401',
          marks: 52
        },
        // Add more subjects
      ];

      // 4. Calculate results for each subject
      const subjectResults: SubjectResult[] = subjects
        .filter(subject => {
          const marksData = marksEvaluation.find(m => m.subjectCode === subject.code);
          const endSemData = endSemEvaluation.find(e => e.subjectCode === subject.code);
          return marksData && endSemData;
        })
        .map(subject => {
          const marksData = marksEvaluation.find(m => m.subjectCode === subject.code)!;
          const endSemData = endSemEvaluation.find(e => e.subjectCode === subject.code)!;

          const totalMarks = 
            marksData.internalAssessment +
            marksData.midSemExam +
            marksData.termWork +
            marksData.practicals +
            endSemData.marks;

          const { grade, gradePoint } = calculateGrade(totalMarks);

          return {
            subjectCode: subject.code,
            subjectName: subject.name,
            credits: subject.credits,
            internalAssessment: marksData.internalAssessment,
            midSemExam: marksData.midSemExam,
            termWork: marksData.termWork,
            practicals: marksData.practicals,
            endSemMarks: endSemData.marks,
            totalMarks,
            grade,
            gradePoint
          };
        });

      // 5. Calculate SGPA
      const sgpa = calculateSGPA(subjectResults);

      // 6. Determine overall status
      const status = subjectResults.some(result => result.grade === 'F') ? 'fail' : 'pass';

      // 7. Create student result
      const studentResult: StudentResult = {
        studentId: student.id,
        studentName: student.name,
        rollNumber: student.rollNumber,
        semester: request.semester,
        results: subjectResults,
        sgpa,
        status
      };

      results.push(studentResult);
    }

    // 8. Generate PDFs for each student (mock for now)
    await generateResultPDFs(results);

    return {
      status: 'success',
      message: 'Results generated successfully',
      results
    };
  } catch (error) {
    return {
      status: 'error',
      message: 'Failed to generate results'
    };
  }
};

// Helper function to generate PDF (mock for now)
const generateResultPDFs = async (results: StudentResult[]): Promise<void> => {
  // Implement PDF generation logic here
  // This could use a library like PDFKit or jsPDF
  console.log('Generating PDFs for', results.length, 'students');
};

// Example usage:
/*
const request: ResultGenerationRequest = {
  semester: 4,
  studentIds: ['STU001', 'STU002']
};

const response = await generateResults(request);
console.log(response);
// Output: {
//   status: 'success',
//   message: 'Results generated successfully',
//   results: [
//     {
//       studentId: 'STU001',
//       studentName: 'John Doe',
//       rollNumber: '2023001',
//       semester: 4,
//       results: [
//         {
//           subjectCode: 'CS401',
//           subjectName: 'Data Structures',
//           credits: 4,
//           internalAssessment: 18,
//           midSemExam: 16,
//           termWork: 18,
//           practicals: 19,
//           endSemMarks: 52,
//           totalMarks: 123,
//           grade: 'A+',
//           gradePoint: 9
//         },
//         // ... more subjects
//       ],
//       sgpa: 8.75,
//       status: 'pass'
//     },
//     // ... more students
//   ]
// }
*/ 