import { generateSeatingArrangement } from './seatingArrangementService';

interface ExamTimetableRequest {
  examTitle: string;
  branch: string;
  semester: string;
  startDate: string; // dd-mm-yyyy
  endDate: string;   // dd-mm-yyyy
  timeSlot: string;  // hh:mm AM/PM
  subjects: string[];
  numberOfSubjects: number;
}

interface ExamDay {
  date: string;      // dd-mm-yyyy
  type: 'EXAM' | 'STUDY_LEAVE';
  subject?: string;  // Present for EXAM type, absent for STUDY_LEAVE
  timeSlot: string;  // hh:mm AM/PM
}

interface ExamTimetable {
  examTitle: string;
  branch: string;
  semester: string;
  schedule: ExamDay[];
}

const parseDate = (dateStr: string): Date => {
  const [day, month, year] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day);
};

const formatDate = (date: Date): string => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

const getDaysBetweenDates = (startDate: string, endDate: string): number => {
  const start = parseDate(startDate);
  const end = parseDate(endDate);
  const diffTime = Math.abs(end.getTime() - start.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
};

const generateDateArray = (startDate: string, days: number): string[] => {
  const dates: string[] = [];
  let currentDate = parseDate(startDate);
  
  for (let i = 0; i < days; i++) {
    dates.push(formatDate(currentDate));
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  return dates;
};

export const generateExamTimetable = (request: ExamTimetableRequest): ExamTimetable | { error: string } => {
  const { 
    examTitle, 
    branch, 
    semester, 
    startDate, 
    endDate, 
    timeSlot, 
    subjects, 
    numberOfSubjects 
  } = request;

  // Validate number of days
  const totalDays = getDaysBetweenDates(startDate, endDate);
  if (totalDays < numberOfSubjects) {
    return { error: 'Insufficient number of days' };
  }

  // Calculate study leaves
  const numberOfStudyLeaves = totalDays - numberOfSubjects;
  const studyLeavesPerExam = Math.floor(numberOfStudyLeaves / (numberOfSubjects - 1));
  const extraStudyLeaves = numberOfStudyLeaves % (numberOfSubjects - 1);

  // Generate all dates
  const allDates = generateDateArray(startDate, totalDays);
  const schedule: ExamDay[] = [];
  
  let currentDateIndex = 0;
  let currentSubjectIndex = 0;

  while (currentDateIndex < allDates.length && currentSubjectIndex < subjects.length) {
    // Add exam day
    schedule.push({
      date: allDates[currentDateIndex],
      type: 'EXAM',
      subject: subjects[currentSubjectIndex],
      timeSlot
    });
    currentDateIndex++;
    
    // Add study leaves if not the last subject
    if (currentSubjectIndex < subjects.length - 1) {
      const studyLeaves = studyLeavesPerExam + (currentSubjectIndex < extraStudyLeaves ? 1 : 0);
      for (let i = 0; i < studyLeaves && currentDateIndex < allDates.length; i++) {
        schedule.push({
          date: allDates[currentDateIndex],
          type: 'STUDY_LEAVE',
          timeSlot
        });
        currentDateIndex++;
      }
    }
    
    currentSubjectIndex++;
  }

  return {
    examTitle,
    branch,
    semester,
    schedule
  };
};

/*
Example Input:
{
  examTitle: "End Semester Examination",
  branch: "Computer Science",
  semester: "IV",
  startDate: "01-05-2024",
  endDate: "10-05-2024",
  timeSlot: "10:00 AM",
  subjects: [
    "Data Structures",
    "Algorithms",
    "Database Systems",
    "Operating Systems"
  ],
  numberOfSubjects: 4
}

Example Output:
{
  examTitle: "End Semester Examination",
  branch: "Computer Science",
  semester: "IV",
  schedule: [
    {
      date: "01-05-2024",
      type: "EXAM",
      subject: "Data Structures",
      timeSlot: "10:00 AM"
    },
    {
      date: "02-05-2024",
      type: "STUDY_LEAVE",
      timeSlot: "10:00 AM"
    },
    {
      date: "03-05-2024",
      type: "EXAM",
      subject: "Algorithms",
      timeSlot: "10:00 AM"
    },
    {
      date: "04-05-2024",
      type: "STUDY_LEAVE",
      timeSlot: "10:00 AM"
    },
    {
      date: "05-05-2024",
      type: "EXAM",
      subject: "Database Systems",
      timeSlot: "10:00 AM"
    },
    {
      date: "06-05-2024",
      type: "STUDY_LEAVE",
      timeSlot: "10:00 AM"
    },
    {
      date: "07-05-2024",
      type: "EXAM",
      subject: "Operating Systems",
      timeSlot: "10:00 AM"
    }
  ]
}

Note: This timetable can be used with seatingArrangementService.ts by passing:
{
  students: [...],
  classrooms: [...],
  constraints: {
    maxStudentsPerBench: 2,
    requireMixedSeating: true,
    preferredMixedCriteria: ['semester']
  }
}

The students array would be filtered based on:
- branch from timetable
- semester from timetable
- subject from current exam day
*/ 