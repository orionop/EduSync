import type { SeatingArrangement } from './seatingArrangementService';

interface Faculty {
  id: string;
  name: string;
  department: string;
  nonAvailabilitySlots: {
    date: string;
    timeSlots: string[]; // e.g., "9:00-10:00", "10:00-11:00"
  }[];
}

type SupervisionDutyType = 
  | 'CLASSROOM_MONITORING'
  | 'ATTENDANCE_MONITORING'
  | 'STUDENT_VERIFICATION'
  | 'ISSUE_HANDLING'
  | 'EXAM_MATERIAL_DISTRIBUTION';

interface SupervisionDuty {
  type: SupervisionDutyType;
  priority: number; // Higher number means higher priority
  requiresFacultyCount: number; // Number of faculty members needed for this duty
}

interface DutyAllocation {
  classroomId: string;
  duties: {
    dutyType: SupervisionDutyType;
    assignedFaculty: Faculty;
  }[];
}

interface SupervisionRequest {
  faculties: Faculty[];
  examDate: string;
  examTimeSlot: string;
  seatingArrangements: SeatingArrangement[];
}

const SUPERVISION_DUTIES: SupervisionDuty[] = [
  {
    type: 'EXAM_MATERIAL_DISTRIBUTION',
    priority: 5,
    requiresFacultyCount: 2
  },
  {
    type: 'STUDENT_VERIFICATION',
    priority: 4,
    requiresFacultyCount: 2
  },
  {
    type: 'CLASSROOM_MONITORING',
    priority: 3,
    requiresFacultyCount: 1
  },
  {
    type: 'ATTENDANCE_MONITORING',
    priority: 2,
    requiresFacultyCount: 1
  },
  {
    type: 'ISSUE_HANDLING',
    priority: 1,
    requiresFacultyCount: 1
  }
];

export const generateSupervisionDuties = (request: SupervisionRequest): DutyAllocation[] => {
  const { faculties, examDate, examTimeSlot, seatingArrangements } = request;
  const dutyAllocations: DutyAllocation[] = [];

  // Filter out unavailable faculty members
  const availableFaculties = faculties.filter(faculty => {
    const nonAvailability = faculty.nonAvailabilitySlots.find(slot => 
      slot.date === examDate && slot.timeSlots.includes(examTimeSlot)
    );
    return !nonAvailability;
  });

  // Sort duties by priority (highest first)
  const sortedDuties = [...SUPERVISION_DUTIES].sort((a, b) => b.priority - a.priority);

  // Calculate total faculty members needed
  const totalFacultyNeeded = sortedDuties.reduce((sum, duty) => sum + duty.requiresFacultyCount, 0);

  // Check if we have enough faculty members
  if (availableFaculties.length < totalFacultyNeeded * seatingArrangements.length) {
    throw new Error('Not enough faculty members available for supervision duties');
  }

  // Create a copy of available faculties that we can modify
  let remainingFaculties = [...availableFaculties];

  // Allocate duties for each classroom
  seatingArrangements.forEach(seating => {
    const allocation: DutyAllocation = {
      classroomId: seating.classroomId,
      duties: []
    };

    // Allocate each duty type
    sortedDuties.forEach(duty => {
      // Get required number of faculty members for this duty
      const facultiesForDuty = remainingFaculties.splice(0, duty.requiresFacultyCount);
      
      // Add duty allocations
      facultiesForDuty.forEach(faculty => {
        allocation.duties.push({
          dutyType: duty.type,
          assignedFaculty: faculty
        });
      });

      // If we've used all faculties, reset the pool
      if (remainingFaculties.length < duty.requiresFacultyCount) {
        remainingFaculties = [...availableFaculties];
      }
    });

    dutyAllocations.push(allocation);
  });

  return dutyAllocations;
};

// Example usage:
/*
const exampleRequest: SupervisionRequest = {
  faculties: [
    {
      id: 'F1',
      name: 'Dr. Smith',
      department: 'Computer Science',
      nonAvailabilitySlots: [
        {
          date: '2024-03-20',
          timeSlots: ['9:00-10:00', '10:00-11:00']
        }
      ]
    }
  ],
  examDate: '2024-03-20',
  examTimeSlot: '9:00-10:00',
  seatingArrangements: [{
    classroomId: 'C1',
    arrangements: []
  }]
};

const exampleDutyAllocations = generateSupervisionDuties(exampleRequest);
*/

// Helper function to validate duty allocation
export const validateDutyAllocation = (
  allocation: DutyAllocation[],
  request: SupervisionRequest
): boolean => {
  // Check if all classrooms have duties assigned
  const allClassroomsHaveDuties = allocation.length === request.seatingArrangements.length;

  // Check if all duty types are assigned for each classroom
  const allDutiesAssigned = allocation.every(classroom => 
    classroom.duties.length === SUPERVISION_DUTIES.reduce((sum, duty) => sum + duty.requiresFacultyCount, 0)
  );

  // Check if faculty members are not double-booked
  const facultyAssignments = new Map<string, number>();
  allocation.forEach(classroom => {
    classroom.duties.forEach(duty => {
      const count = facultyAssignments.get(duty.assignedFaculty.id) || 0;
      facultyAssignments.set(duty.assignedFaculty.id, count + 1);
    });
  });

  const noDoubleBooking = Array.from(facultyAssignments.values()).every(count => count <= 1);

  return allClassroomsHaveDuties && allDutiesAssigned && noDoubleBooking;
}; 