interface Student {
  id: string;
  name: string;
  group: string;  // Will contain actual branch-semester (e.g., "CS-Sem4")
}

interface Classroom {
  id: string;
  name: string;
  numberOfBenches: number;  // Fixed at 20
}

interface StudentPosition {
  student: Student;
  position: 'LEFT' | 'RIGHT';
}

export interface SeatingArrangement {
  classroomId: string;
  classroomName: string;
  arrangements: {
    benchNumber: number;
    students: StudentPosition[];
  }[];
}

interface SeatingRequest {
  groupA: {
    branchSemester: string;  // e.g., "CS-Sem4"
    students: Omit<Student, 'group'>[];  // Students without group field
  };
  groupB: {
    branchSemester: string;  // e.g., "IT-Sem6"
    students: Omit<Student, 'group'>[];  // Students without group field
  };
  numberOfClassrooms: number;
}

export const generateSeatingArrangement = (request: SeatingRequest): SeatingArrangement[] => {
  const { groupA, groupB, numberOfClassrooms } = request;
  const arrangements: SeatingArrangement[] = [];
  
  // Create classrooms with 20 benches each
  const classrooms: Classroom[] = Array.from({ length: numberOfClassrooms }, (_, i) => ({
    id: `C${i + 1}`,
    name: `Classroom ${i + 1}`,
    numberOfBenches: 20
  }));

  // Add group information to students
  let groupAStudents = groupA.students.map(student => ({
    ...student,
    group: groupA.branchSemester
  }));

  let groupBStudents = groupB.students.map(student => ({
    ...student,
    group: groupB.branchSemester
  }));
  
  // Process each classroom
  for (const classroom of classrooms) {
    const classroomArrangement: SeatingArrangement = {
      classroomId: classroom.id,
      classroomName: classroom.name,
      arrangements: []
    };

    // Process each bench in the classroom
    for (let benchNumber = 1; benchNumber <= classroom.numberOfBenches; benchNumber++) {
      const benchArrangement = {
        benchNumber,
        students: [] as StudentPosition[]
      };

      // Try to seat one student from each group
      if (groupAStudents.length > 0) {
        benchArrangement.students.push({
          student: groupAStudents.shift()!,
          position: 'LEFT'
        });
      }

      if (groupBStudents.length > 0) {
        benchArrangement.students.push({
          student: groupBStudents.shift()!,
          position: 'RIGHT'
        });
      }

      if (benchArrangement.students.length > 0) {
        classroomArrangement.arrangements.push(benchArrangement);
      }
    }

    if (classroomArrangement.arrangements.length > 0) {
      arrangements.push(classroomArrangement);
    }

    // If no more students left, break
    if (groupAStudents.length === 0 && groupBStudents.length === 0) {
      break;
    }
  }

  return arrangements;
};

// Example usage:
/*
const request: SeatingRequest = {
  groupA: {
    branchSemester: "CS-Sem4",
    students: [
      { id: "CS1", name: "John" },
      { id: "CS2", name: "Jane" },
      // ... more students
    ]
  },
  groupB: {
    branchSemester: "IT-Sem6",
    students: [
      { id: "IT1", name: "Alice" },
      { id: "IT2", name: "Bob" },
      // ... more students
    ]
  },
  numberOfClassrooms: 2
};

Example Output:
[
  {
    "classroomId": "C1",
    "classroomName": "Classroom 1",
    "arrangements": [
      {
        "benchNumber": 1,
        "students": [
          { "student": { "id": "CS1", "name": "John", "group": "CS-Sem4" }, "position": "LEFT" },
          { "student": { "id": "IT1", "name": "Alice", "group": "IT-Sem6" }, "position": "RIGHT" }
        ]
      },
      {
        "benchNumber": 2,
        "students": [
          { "student": { "id": "CS2", "name": "Jane", "group": "CS-Sem4" }, "position": "LEFT" },
          { "student": { "id": "IT2", "name": "Bob", "group": "IT-Sem6" }, "position": "RIGHT" }
        ]
      }
      // ... more benches
    ]
  }
  // ... more classrooms
]
*/ 